<p><hr></p>
<h4>Actual Time Table</h4>
<div class="col-xs-12">

    <table class="table table-striped" id="myAttendance">
        <thead>
        <tr>
            <th>Date</th>
            <th>Code</th>
            <th>Description</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th>Start Diff</th>
            <th>End Diff</th>
            <th>Late</th>
            <th>Undertime</th>
            <th>Deduction</th>

        </tr>
        </thead>
        <tbody>
        <?php
        foreach($results as $row){
            ?>
            <tr>


                <td><?php echo $row->date?></td>
                <td><?php echo $row->code?></td>
                <td><?php echo $row->dsc?></td>
                <td><?php echo $row->start_time?></td>
                <td><?php echo $row->end_time?></td>
                <td><?php echo $row->timein?></td>
                <td><?php echo $row->timeout?></td>
                <td><?php echo $row->start_diff?></td>
                <td><?php echo $row->end_diff?></td>
                <td><?php echo $row->late?></td>
                <td><?php echo $row->undertime?></td>
                <td>TBA</td>
            </tr>
        <?php
        }
        ?>


        </tbody>
    </table>

</div>

<script>
    $(document).ready(function(){

        var table = $('#myAttendance').DataTable({
            "bSort": false,
            "searching": false,
            "paginate": false
        });

        $('#myAttendance tbody').on( 'click', 'tr', function () {

            if ( $(this).hasClass('selected') ) {

                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        } );

//        var calendar = $("#calendar").calendar(
//            {
//                tmpl_path: "/ers/public/tmpls/",
//                events_source:
//                    <?php //print_r($jsonData)?>
//
//
//
//            });


    });





</script>