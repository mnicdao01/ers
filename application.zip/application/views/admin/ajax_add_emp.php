
<form role="form" id="frmAddEmployee" enctype="multipart/form-data" method="post">

    <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" placeholder="Email" name="email"/>

    </div>
    <div class="form-group">
        <label for="empid">Username</label>
        <input type="text" class="form-control" placeholder="Username" name="empid"/>

    </div>
    <div class="form-group">
        <label for="fname">First Name</label>
        <input type="text" class="form-control" placeholder="First Name" name="fname"/>

    </div>
    <div class="form-group">
        <label for="mname">Middle Name</label>
        <input type="text" class="form-control" placeholder="Middle Name" name="mname"/>
    </div>
    <div class="form-group">
        <label for="lname">Last Name</label>
        <input type="text" class="form-control" placeholder="Last Name" name="lname"/>
    </div>
    <div class="form-group">
        <label for="dept">Department</label>
        <select class="form-control" name="dept">
           <?php foreach($dept as $row){?>
            <option value="<?php echo $row->dsc?>"><?php echo $row->dsc?></option>
            <?php }?>
        </select>
    </div>
    <div class="form-group">
        <label for="paddress">Permanent Address</label>
        <textarea class="form-control" placeholder="Permanent Address" name="paddress"/>
    </div>
    <div class="form-group">
        <label for="taddress">Temporary Address</label>
        <textarea class="form-control" placeholder="Temporary Address" name="taddress"/>
    </div>
    <div class="form-group">
        <label for="i_cno">Indonesia Phone No.</label>
        <input type="text" class="form-control" placeholder="Indonesia Contact No." name="i_cno"/>
    </div>
    <div class="form-group">
        <label for="w_cno">Work Phone No.</label>
        <input type="text" class="form-control" placeholder="Work Contact No." name="w_cno"/>
    </div>
    <div class="form-group">
        <label for="p_birth">Place of Birth</label>
        <input type="text" class="form-control" placeholder="Place of Birth" name="p_birth"/>
    </div>
    <div class="form-group">
        <label for="d_birth">Birthday</label>
        <input type="date" class="form-control" placeholder="Birthday" name="d_birth"/>
    </div>
    <div class="form-group">
        <label for="visano">Visa Number</label>
        <input type="text" class="form-control" placeholder="Visa Number" name="visano"/>
    </div>
    <div class="form-group">
        <label for="c_visa">Visa Created Date</label>
        <input type="date" class="form-control" placeholder="Visa Created Date" name="c_visa"/>
    </div>
    <div class="form-group">
        <label for="e_visa">Visa Expiration Date</label>
        <input type="date" class="form-control" placeholder="Visa Created Date" name="e_visa"/>
    </div>
    <div class="form-group">
        <label for="join_date">Join Date</label>
        <input type="date" class="form-control" placeholder="Join Date" name="join_date"/>
    </div>


    <div id="files"></div>

    <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal" id="btnClose">Close</button>
        <button type="submit" class="btn btn-primary" id="btnSaveEmp">Save</button>

    </div>

</form>


<script>

    $(function() {
        var ip = $('#txtIP').val();
        var location = $('#txtLocation').val();

        $('#frmAddEmployee').submit(function(e) {
            var params = $('#frmAddEmployee').serialize();
            e.preventDefault();
            $.post('main/upload_file_emp?'+params,function (data){
                  if(data == true){
                  $('#myModal').modal('hide');

                  alertify.success("Added Successfully");
                    $('#btnEmployee').trigger('click');
                  }
                else{
                      alertify.error("Error adding new employee information");
                  }

            });
            return false;
        });


    });



    $(document).ready(function(){
        $('#btnClose').on('click', function(){

            $.post(base_url + 'admin/main/load_employee',function(data){
                $('#body_content').html(data);
            });
        })
    });
</script>
