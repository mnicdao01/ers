<h1>My Profile <small> Any information here are kept confidential. - HRD</small></h1>
<hr>
<h3>Personal Information</h3>
<form id="frmUpdateProfile" method="post">
<div class="row">
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtFName">First Name</label>
            <input type="text" id="txtFName" class="form-control" placeholder="First Name" value="<?php echo $results[0]->fname?>" name="fname"/>
        </div>

    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtMName">Middle Name</label>
            <input type="text" id="txtMName" class="form-control" placeholder="Middle Name" value="<?php echo $results[0]->mname?>" name="mname"/>
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtLName">Last Name</label>
            <input type="text" id="txtLName" class="form-control" placeholder="Last Name" value="<?php echo $results[0]->lname?>" name="lname"/>
        </div>
    </div>
    <div class="col-xs-3" hidden>
        <img src="" alt="My Profile Picture" width="150"/>
    </div>
</div>
<div class="row">
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtEmail">Email Address</label>
            <input type="text" id="txtEmail" class="form-control" placeholder="Email Address" value="<?php echo $results[0]->email?>" name="email"/>
        </div>
    </div>
    <div class="col-xs-6">
        <div class="form-group">
            <label for="selDept">Department</label>
            <select id="selDept" name="dept" class="form-control">
                <?php foreach($dept as $row){

                    if($row->dsc == $dept_get){
                        echo "<option selected='selected' value='$row->dsc'>$row->dsc</option>";
                    }
                    else{
                        echo "<option value='$row->dsc'>$row->dsc</option>";
                    }

                } ?>
            </select>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-xs-9">
        <div class="form-group">
            <label for="txtPAdd">Permanent Address</label>
            <textarea id="txtPAdd" placeholder="Permanent Address" class="form-control" name="paddress"><?php echo $results[0]->paddress?></textarea>
        </div>
    </div>
    <div class="col-xs-9">
        <div class="form-group">
            <label for="txtTAdd">Temporary Address</label>
            <textarea id="txtTAdd" placeholder="Temporary Address" class="form-control" name="taddress"><?php echo $results[0]->taddress?></textarea>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtICno">Indonesian/Personal Contact Number</label>
            <input type="text" id="txtICno" class="form-control" placeholder="Indonesian Contact Number" value="<?php echo $results[0]->i_cno?>" name="i_cno"/>
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtWCno">Work Contact Number</label>
            <input type="text" id="txtWCno" class="form-control" placeholder="Work Contact Number" value="<?php echo $results[0]->w_cno?>" name="w_cno"/>
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtBDay">Birthday</label>
            <input type="date" id="txtBDay" class="form-control" placeholder="Birthday" value="<?php echo $results[0]->d_birth?>" name="d_birth"/>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-9">
        <div class="form-group">
            <label for="txtPBirth">Place of Birth</label>
            <textarea id="txtPBirth" placeholder="Place of Birth" class="form-control" name="p_birth"><?php echo $results[0]->p_birth?></textarea>
        </div>
    </div>
</div>
<hr>
<h3>Work and Visa Information</h3>
<div class="row">
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtVisaNo">Visa Number</label>
            <input type="text" id="txtVisaNo" placeholder="Visa Number" class="form-control" value="<?php echo $results[0]->visano?>" name="visano">
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtVisaCreated">Visa Creation Date</label>
            <input type="date" id="txtVisaCreated" placeholder="Visa Creation Date" class="form-control" value="<?php echo $results[0]->c_visa?>" name="c_visa">
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtVisaExpired">Visa Expiration Date</label>
            <input type="date" id="txtVisaExpired" placeholder="Visa Expiration Date" class="form-control" value="<?php echo $results[0]->e_visa?>" name="e_visa">
        </div>
    </div>
    <div class="col-xs-3">
        <div class="form-group">
            <label for="txtJoinDate">Date of Employment</label>
            <input type="date" id="txtJoinDate" placeholder="Date of Employment" class="form-control" value="<?php echo $results[0]->join_date?>" name="join_date">
        </div>
    </div>
</div>
<input type="submit" id="btnUpdateProfile" value="Update" class="btn btn-info">

</form>


<script>
    $('#frmUpdateProfile').submit(function(e) {
        var params = $('#frmUpdateProfile').serialize();

        e.preventDefault();
        $.post('main/update_profile?'+params,function(data){
            if(data==true){
                $('#myModal').modal('hide');
                alertify.success("Updated successfully");

            } else
            {
                alertify.error("Error saving");
            }
        });
        return false;
    });
</script>

