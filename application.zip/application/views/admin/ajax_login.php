<table class="table wy-table-responsive" id="login">
    <thead>
    <tr>
        <th>Login Employees</th>
    </tr>
    <tr>
        <th>ID</th>
        <th>FULL NAME</th>
        <th>TIME IN</th>
        <th>DEPARTMENT</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($results as $row){?>
        <tr>
            <td><?php echo $row->ID?></td>
            <td><?php echo $row->FULLNAME?></td>
            <td><?php echo $row->TIMEIN?></td>
            <td><?php echo $row->DEPT?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>