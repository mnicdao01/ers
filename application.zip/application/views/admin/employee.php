
            <h1>Employee Information<small> Manage Employee Information</small></h1>
            <div class="btn-group" role="group" style="margin-bottom: 10px; padding: 10px; border: 1px lightgray solid;">
                <button type="button" class="btn btn-primary" id="btnAddEmp">Add</button>
                <button type="button" class="btn btn-info" id="btnEditEmp">Edit</button>
                <button type="button" class="btn btn-danger" id="btnDeleteEmp">Delete</button>

            </div>

            <table class="table table-striped" id="table_employee">
                <thead>
                    <tr>

                        <th>ID</th>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Department</th>


                    </tr>
                </thead>
                <tbody>

                <?php foreach($employee as $row){?>
                    <tr>
                        <td><?php echo $row->id?></td>
                        <td><?php echo $row->empid?></td>
                        <td><?php echo strtoupper($row->fname." ".$row->mname." ".$row->lname)?></td>
                        <td><?php echo $row->dept?></td>

                    </tr>
                <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="4">

                    </td>
                </tr>
                </tfoot>
            </table>

<script>

    $(document).ready( function () {

        var table = $('#table_employee').DataTable();

        $('#table_employee tbody').on( 'click', 'tr', function () {

            if ( $(this).hasClass('selected') ) {

                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        } );

        $('#btnAddEmp').on('click', function(){

            $('#myModal').modal('show');
            $.post('main/add_emp', function(data){
                $('#modal_body').html(data);

            });

        });

        $('#btnDeleteEmp').click( function () {

            alertify.confirm('Are you sure you want to delete?').set('onok', function(closeEvent){
                var id = table.cell('.selected',0).data();

                table.row('.selected').remove().draw( false );

                $.post('main/delete_emp', {id: id}, function (data){

                    if(data==true){
                        alertify.success("Deleted Successfully");
                    }
                    else {
                        alertify.error("Error in deleting record");
                    }

                })
            });

        } );

        $('#btnEditEmp').on('click', function(data){
            var id = table.cell('.selected',0).data();
            var empid = table.cell('.selected',1).data();
            var name= table.cell('.selected',2).data();
            var dept = table.cell('.selected',3).data();


            $('#myModal').modal('show');
            $.post('main/edit_emp',{id:id,empid:empid,name:name,dept:dept}, function(data){
                $('#modal_body').html(data);


            });

        });



    } );
</script>