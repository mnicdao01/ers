<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Dashboard <small>Statistics Overview</small>
            </h1>
            <ol class="breadcrumb">
                <li class="active">
                    <i class="fa fa-dashboard"></i> Control Panel
                </li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

<!--    <div class="row">-->
<!--        <div class="col-lg-3 col-md-6">-->
<!--            <div class="panel panel-primary">-->
<!--                <div class="panel-heading">-->
<!--                    <div class="row">-->
<!--                        <div class="col-xs-3">-->
<!--                            <i class="fa fa-comments fa-5x"></i>-->
<!--                        </div>-->
<!--                        <div class="col-xs-9 text-right">-->
<!--                            <div class="huge">26</div>-->
<!--                            <div>New Comments!</div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <a href="#">-->
<!--                    <div class="panel-footer">-->
<!--                        <span class="pull-left">View Details</span>-->
<!--                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>-->
<!--                        <div class="clearfix"></div>-->
<!--                    </div>-->
<!--                </a>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-lg-3 col-md-6">-->
<!--            <div class="panel panel-green">-->
<!--                <div class="panel-heading">-->
<!--                    <div class="row">-->
<!--                        <div class="col-xs-3">-->
<!--                            <i class="fa fa-tasks fa-5x"></i>-->
<!--                        </div>-->
<!--                        <div class="col-xs-9 text-right">-->
<!--                            <div class="huge">12</div>-->
<!--                            <div>New Tasks!</div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <a href="#">-->
<!--                    <div class="panel-footer">-->
<!--                        <span class="pull-left">View Details</span>-->
<!--                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>-->
<!--                        <div class="clearfix"></div>-->
<!--                    </div>-->
<!--                </a>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-lg-3 col-md-6">-->
<!--            <div class="panel panel-yellow">-->
<!--                <div class="panel-heading">-->
<!--                    <div class="row">-->
<!--                        <div class="col-xs-3">-->
<!--                            <i class="fa fa-shopping-cart fa-5x"></i>-->
<!--                        </div>-->
<!--                        <div class="col-xs-9 text-right">-->
<!--                            <div class="huge">124</div>-->
<!--                            <div>New Orders!</div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <a href="#">-->
<!--                    <div class="panel-footer">-->
<!--                        <span class="pull-left">View Details</span>-->
<!--                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>-->
<!--                        <div class="clearfix"></div>-->
<!--                    </div>-->
<!--                </a>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-lg-3 col-md-6">-->
<!--            <div class="panel panel-red">-->
<!--                <div class="panel-heading">-->
<!--                    <div class="row">-->
<!--                        <div class="col-xs-3">-->
<!--                            <i class="fa fa-support fa-5x"></i>-->
<!--                        </div>-->
<!--                        <div class="col-xs-9 text-right">-->
<!--                            <div class="huge">13</div>-->
<!--                            <div>Support Tickets!</div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <a href="#">-->
<!--                    <div class="panel-footer">-->
<!--                        <span class="pull-left">View Details</span>-->
<!--                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>-->
<!--                        <div class="clearfix"></div>-->
<!--                    </div>-->
<!--                </a>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->

    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-primary">
                <div class="panel-heading">All Logged-in Employees</div>
                <div class="panel-body">
                    <div class="filter">
                        <label for="selDept">Select Department</label>
                       <select class="form-control" id="selDept">
                           <option value="all">All</option>
                           <?php foreach($filter_department as $row){?>
                           <option value="<?php echo $row->dsc?>"><?php echo $row->dsc?></option>
                            <?php }?>
                       </select>
                    </div>
                    <div id="ajax_login"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->



</div>

<script>
    $(document).ready(function (){

        var base_url = $('#base_url').val();

//        var auto_start = setInterval(function (){
            $.post('main/load_ajax_login', function(data){
                $('#ajax_login').html(data);
            });
//        }, 0);


        $('#selDept').change(function(){
           var selected = $(this).val();

            if(selected == 'all'){


                    $.post('main/load_ajax_login', function(data){
                        $('#ajax_login').html(data);
                    });

            }
            else {


                    $.post('main/load_ajax_login_dept', {dept: selected}, function (data) {
                        $('#ajax_login').html(data);
                    });

            }

        });




    });
</script>